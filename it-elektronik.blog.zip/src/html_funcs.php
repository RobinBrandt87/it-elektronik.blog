<?php

  
/*############################################################################
//function Menu()

Liefert das Hauptmenu als Html String 

Phase 1 Statisch erledigt entfernt
Phase 2 Dynamisch aus DB in arbeit

###########################################################################*/
function Menu()
{

    $html = "<div class=\"Menu\"> 
            \n  <h1><span>IT-Elektronik Blog</span></h1>
            \n  <ul>";
    $MenuArr = GetMenu();
    foreach($MenuArr as $Menu)
    {
        $html .= "
                  \n   <li class=\"".$Menu['class']."\"><a href=\"".$Menu['action'].SID."&amp;ID=".$Menu['Position']."\">".$Menu['Name']."</a>
                  ";
                  $SubArr = GetSubMenuByMenuID($Menu['Position']);
                  //DebugArr ($SubArr);
                  if(isset($SubArr['0']))
                  {
                      $html .= "\n      <ul>";
                        foreach($SubArr as $Sub)
                        {
                            $html .="\n   <li><a href=\"".$Sub['action'].SID."&amp;ID=".$Sub['MenuID']."&amp;Sub=".$Sub['Position']."\">".$Sub['Name']."</a></li>";
                        }
                  $html .="
                  \n      </ul>";                      
                  }

        $html .= "\n  </li>";
    }
    $html .= "  \n      </ul>
                \n  </div>";
    return $html;
}
/*############################################################################
//function SideMenu()

Liefert das Passende SideMenu als Html String 

Phase 1 Statisch erledigt entfernt

    <div class=\"SideMenu\">
        <ul>
            <li class=\"SideMenu1\"><a href=\"#SSD_f&uuml;r_20€\">SSD f&uuml;r 20€</a>   
            <ul class=\"SideMenu\">
            <li class=\"SideMenu1\"><a href=\"#\">Wieso ...</a></li>
            <li class=\"SideMenu1\"><a href=\"#Festplatte\">Festplatte</a></li>
            <li class=\"SideMenu1\"><a href=\"#Vorteile_SSD\">Vorteile SSD</a></li>    
            </ul></li>               
            <li class=\"SideMenu1\"><a href=\"#\">PlatzHalter</a></li>
            <li class=\"SideMenu1\"><a href=\"#\">PlatzHalter</a></li>
            <li class=\"SideMenu1\"><a href=\"#\">PlatzHalter</a></li>
        </ul>
    </div>"


Phase 2 Dynamisch aus DB in arbeit

###########################################################################*/
function SideMenu($ID,$SID='')
{
    $I = 0;
    $html ="";
    if(isset($ID))
    {
        $html .="<div class=\"SideMenu\">";
        $ID = $ID;        // - 1 Weil es die ID 0 in der Datenbank gibt aber im Browser es mit 1 anf&auml;ngt
        if($SID == '')
        {
            $SubArr = GetSubMenuByMenuID($ID);
            

            if (isset($SubArr['0']['Position']))
            {
                $html .="
                        <ul>";

                foreach($SubArr as $Sub)
                {
                    //echo "bla";
                    $html .="<li class=\"SideMenu1\"><a href=\"index.php?".SID."&amp;ID=".$ID."&amp;Sub=".$Sub['Position']."\">".$Sub['Name']."</a></li>";    
                    $I=$I+1;
                }
                if($I>=1)
                {
                    $html .="</ul>";
                }                     
            }
   
            
        }
        else
        {
            //echo $ID;
            //echo $SID;
            $SuBArr = GetSubMenuByMenuIDSubID($ID,$SID);
            //DebugArr($SuBArr);

            if (isset($SuBArr['0']['A_ID']))
            {
                $html .="
                        <ul>";

                foreach($SuBArr as $SuB)
                {
                    
                    $html .="<li class=\"SideMenu1\"><a href=\"index.php?".SID."&amp;AID=".$SuB['A_ID']."\">".$SuB['A_Name']."</a></li>";    
                    $I=$I+1;
                }
                if($I>=1)
                {
                    
                    $html .="</ul>";
                }
            }

        }
        /*
        $html .="
        <div class=\"SideMenu\">
            <ul>
                <li class=\"SideMenu1\"><a href=\"#SSD_f&uuml;r_20€\">SSD f&uuml;r 20€</a>   
                <ul class=\"SideMenu\">
                <li class=\"SideMenu1\"><a href=\"#\">Wieso ...</a></li>
                <li class=\"SideMenu1\"><a href=\"#Festplatte\">Festplatte</a></li>
                <li class=\"SideMenu1\"><a href=\"#Vorteile_SSD\">Vorteile SSD</a></li>    
                </ul></li>               
                <li class=\"SideMenu1\"><a href=\"#\">PlatzHalter</a></li>
                <li class=\"SideMenu1\"><a href=\"#\">PlatzHalter</a></li>
                <li class=\"SideMenu1\"><a href=\"#\">PlatzHalter</a></li>
            </ul>
        </div>";
        */
        $html .= "
            </div>";
    }
    else
    {
        $html = "";
    }
   
    return $html;


}

/*###########################################################################
// function footer()

Liefert den Standart Footer
##########################################################################*/
function footer()
{
    $html = "    
    <div class=\"footer\">
        <div class=\"links\">
            <a>&copy; Robin Brandt </a>
        </div>
        <div class=\"rechts\">
            <a href=\"Impressum.php?".SID."\">Impressum</a>
        </div>
    </div>";
    return $html;
}
/* ****************************************************************
function PrintErrorDiv( $errno );

Diese Funktion erzeugt ein g&uuml;ltiges HTML-Div der Klasse error
mit formatierter Fehlerbeschreibung

Parameter:     $errno : eine Fehlernummer 
												bisher vergeben: siehe Switch-Case

R&uuml;ckgabewerte: Das fertige HTML-Div als String

******************************************************************* */
function PrintErrorDiv( $errno )
{
  switch ( $errno )
	{
    case 10 : 
			$title = "Falsche Anmeldedaten";
			$desc  = "Diese Kombination aus Benutzername und Passwort ist ung&uuml;ltig. Bitte geben Sie Ihre korrekten Daten erneut ein.";
			break;
		case 11 : 
			$title = "Fehlende Anmeldedaten";
			$desc  = "Um sich im Intranet anzumelden m&uuml;ssen ".
					"Sie <span class=\"wichtig\">alle</span> Felder im Formular ".
					"ausf&uuml;llen.";
			break;
		case 12 : 
			$title = "Fehlende Anmeldung";
			$desc  = "Um unser Internet zu betreten, m&uuml;ssen Sie sich vorher anmelden. Bitte benutzen Sie zuk&uuml;nftig immer diese Anmeldesite als Startseite.";
			break;
		default : 
			$title = "Unbekannte Fehlernummer";
			$desc  = "Sorry - Dieser Fall h&auml;tte nicht passieren d&uuml;rfen...";
	}

	// Fehlermeldung: 
	$errmsg = 
		"\n<div class=\"error\">".
		"\n\t<div class=\"title\">".$title."</div>".
		"\n\t<div class=\"desc\">".$desc."</div>".
		"\n</div>";

	return $errmsg;
}
/*#####################################################################################
	Print_MitarbeiterTable($Mitarbeiterrarr);
	
	Diese Funktion erzeugt ein g&uuml;ltiges XHTML DIV mit einer g&uuml;ltigen HTML Tabelle mit allen MitarbeiterDaten
	
	Parameter 
    
	$lehrerarr		 Ein Zweidiemensianalen assioziatives array aller Mitarbeiter
	$OptionalerParm  Ein Optionaler Parameter der zur Bearbeiten ausgabe 
    
	r&uuml;ckgabe 		 das fertige html Div als String 
	
	#####################################################################################*/
	function Print_VerwaltungsTable()
	{
    $MenuArr = GetMenuAll();  
    $table.="<form method=\"post\"".
                   "action= \"".$_SERVER['PHP_SELF']."?".SID 
                   ."\">"; 
    $table.="<table>
            \n  <thead>
            \n      <tr>
            \n          <th>MenuPosition</th>
            \n          <th>MenuName</th>
            \n          <th>MenuClass</th>
            \n          <th>MenuAction</th>
            \n          <th>MenuStatus</th>
            \n          <th>Aktion</th>
            \n      </tr>
            \n  </thead>
            \n  <tbody>";
            foreach($MenuArr as $Menu)
            {
                $table .= "
            \n      <tr>
            \n          <td>".$Menu['Position']."</td>
            \n          <td>".$Menu['Name']."</td>
            \n          <td>".$Menu['class']."</td>
            \n          <td>".$Menu['action']."</td>
            \n          <td>".$Menu['Status']."</td>";
            if($Menu['Status']=="Gesperrt")
            {
                $table .= "
                \n          <td><input type=\"submit\" name=\"Aktivieren\" class=\"Aktivieren\" value=\"".$Menu['ID']."\"/></td>
                \n      </tr>";
            }
            else
            {
                $table .= "
                \n          <td><input type=\"submit\" name=\"Sperren\" class=\"Sperren\" value=\"".$Menu['ID']."          "."\"/></td>
                \n      </tr>";                
            }

            }
    $table.="
            \n  </tbody>
            \n  </table>
            \n  </form>";            




	return $table;
    }
	/*#######################################################################################
<div id="Inhalt">
        <h2 id="Abschnitt_0" >Wilkommen auf IT-Elektronik.blog</h2>
        <p>
        <a href="#Abschnitt_0"> - Wer bin Ich ? </a><br/>        
        <a href="#Abschnitt_1"> - Was hab ich vor ? </a><br/>
        <a href="#Abschnitt_2"> - Was will ich erreichen ? </a><br/>
        <a href="#Abschnitt_3"> - Wie will ich das umsetzen ? </a><br/>
        <a href="#Abschnitt_4"> - Open Source :-) </a><br/>
        <a href="#Abschnitt_5"> - Feedback :-) </a><br/>
        
        </p>
        <p> Hi bevor ich mich jetzt Wochenlang um den Starttermin des Blogs dr&uuml;cke... dr&uuml;cke ich lieber
            den START-Knopf. Das Backend ist noch nicht fertig komplett fertig.
        </p>
        <h3 id="Abschnitt_1" >Wer bin Ich ?</h3>
        <p> Mein Name ist Robin Brandt, ich bin staatlich gepr&uuml;fter Techniker f&uuml;r Energietechnik. Das 
            hat im ersten und zweiten Moment wenig mit Datentechnik zu tun. Im dritten Moment jedoch schon. 
        </p>
        <h4>Ein Beispiel</h4>
        <p> Es l&auml;sst sich ohne viel Fantasie ein Vergleich zwischen der Lastverteilung von Datenstr&ouml;men
            im Internet und der Lastverteilung von Strom im Energieveteilungsnetz der Bundesrepublik ziehen             
        </p>
        <p> Das ist nur ein Beispiel andere Beispiele sind SmartHome, Elektromobilit&auml;t selbst K&uuml;hlschr&auml;nke 
            k&ouml;nnen heute schon eine eigen IP haben und mittels dem Internet mit dem Smartphone 
            kommunizieren d.h. der K&uuml;hlschrank kann Euch die Einkaufsliste schicken .... Gruselig.
        </p>
        <h3 id="Abschnitt_2">Was hab ich vor ?</h3>
        <p> Ich verliere mich schon wider im Detail. In meiner Freizeit besch&auml;ftige ich mich viel mit 
            eben diesen Dingen und um mir das besser merken zu k&ouml;nnen schreib ich mir das online einfach
            und verst&auml;ndlich auf. Das macht es einfacher mich daran zu erinnern oder wenn jemand Fragt:
            "Wie funktioniert das Eigentlich?" zu Antworten ohne Stundenlang alles im Detail erkl&auml;ren zu 
            m&uuml;ssen 
        </p>            
        <h3 id="Abschnitt_3">Was will ich erreichen ?</h3>
        <p> Mit einer online Pr&auml;senz will/verfolgt man meistens ein bestimmtes Ziel. Entweder hohe Klick zahlen
            gepaart mit Werbung. Nat&uuml;rlich freue ich mich wenn nicht nur Ich meinen eigenen Blog lese, doch mit
            Klick zahl &amp; Werbung m&ouml;chte ich eher weniger bis gar nichts zu tun haben. H&ouml;chsten Werbung f&uuml;r mich
            selbst ^^. Deswegen verzichte ich auf diese ganzen nervigen Werbeeinblendungen. Das f&auml;llt mir Pers&ouml;nlich
            auch auf anderen Internetseiten negativ auf:"Oh Sie benutzen einen Addblocker um den Inhalt der Seite zu lesen ..."
            So denn kennen wir wohl Alle. Gibt's hier nicht, wenn ich hier mal ein Produkt vorstelle, dann nur weil ich
            das zu Verwirklichung von irgendwelchen Projekten brauche. Warum ich dann gerade den Raspberry Pi und nicht den
            Bannna Pi nutze ist meiner Willk&uuml;r &uuml;berlassen. Kauft, was immer ihr f&uuml;r die Realisierung eurer Projekte f&uuml;r
            das beste Mittel haltet.  
        </p>
        <h3 id="Abschnitt_4">Wie will ich das umsetzen ?</h3>
        <p> Nun ich werde mich bem&uuml;hen pro Woche wenigstens einen Artikel zu schreiben. Oder auch mal zwei in einer
            Woche und daf&uuml;r n&auml;chste Woche keinen. N&auml;chstes Jahr also Kalenderwoche 37 2018 hat diese Seite mindestens
            53 Artikel. <br/>
            Als gro&szlig;er Verfechter von HTML CSS und PHP werde ich versuchen diese Seite komplett ohne Java Script zu
            gestalten d.h. volle Funktionalit&auml;t dieser Seite bei ausgeschaltetem Java Script. Ich m&ouml;chte ja auch nicht,
            das fremder Code so ganz ohne mein wissen bei mir ausgef&uuml;hrt wird.               
        </p>       
        <h3 id="Abschnitt_5">Open Source</h3>
        <p> Ich m&ouml;chte euch liebe Leser nicht nur zeigen was alles geht sondern konkret wie es geht. Dabei strebe ich ein
            gewisses Ma&szlig; an Sicherheit an das ich durch SSL in der &uuml;bertragung und des schrittweisen ver&ouml;ffentlichen und besprechen
            des Quellcodes dieser Seite (ausgenommen Passw&ouml;rter die bleiben Geheim)<br/>
            Kleine Anekdote dazu. Ich kenne Programme (Diese sind gerade noch in Entwicklung) da werden Passw&ouml;rter offline im Klartext
            gespeichert. Das sind Anwendungen die mit Servern im Internet kommunizieren! SSL ist nur eine Option?! Hallo ???<br/>
        </p>    
        <h3>Wer Passw�rter offline im Klartext speichert und bei dem SSL nur Option und nicht Sandart ist <br/>
            und dann eine Dicke Stange Geld haben will, kann gleich wieder abtreten.
        </h3>
        <p>   
            Also merkt euch SSL an Passw&ouml;rter auch mit SSL nicht im Klartext Speichern und nehmt sichere Passw&ouml;rter 123456789 <br/> 
            ist bestimmt auch in einer Rainbowtable f&uuml;r SHA512 und besser zu finden.   
        </p> 
        <h3 id="Abschnitt_6">Feedback</h3>    
        <p> Gerne Anregungen, Fragen, Lob und Kritik nehme ich gerne an ;-) Kontakt sieh <a href="Impressum.php">Impressum</a>    
        
        </p>
          
    </div>   


    #######################################################################################*/
    function Inhalt($AID)
    {
        $HTML="";
        If(!isset($AID))
        {
            $AID = 1;
        }
        $html = Artikel($AID);
        //DebugArr($html['HTML']);
        $HTML = $html['HTML'];
        return $HTML;
    }
?>