<?php
/*###########################################################################
  // Debugging-Funktion für Arrays inherhalb von PHP
  debugging fuktion für arrays innerhalb von PHP Gibt als präformatierten Text ein Array
  in einem div der klasse debug aus 
  Ausgabe erfolgt nur bei einer gesestzten Globalen Konstante namens MYDEBUG
  
  Parameter $arr - ein Array
   
############################################################################*/  
function DebugArr( $arr )
{
	if ( defined('MYDEBUG') && MYDEBUG )
	{
		/* Testausgabe: was bekommen wir
			 Ausgabe aller GET-Daten           */
		echo "\n<div class=\"debug\"><pre>";
		print_r( $arr );
		echo "</pre></div>";
	}
		
}
/* **********************************************************
	function PflichtfelderOK( );

  Überprüft bei der Anmeldung ob die Felder 'login' und 'passwd'
	ausgefüllt wurden

	Parameter: keine ABER benötigt POST als Übergabemethode!

	Rückgabewerte: 
			true: alles ausgefüllt
			false: sonst
*********************************************************** */
	function PflichtfelderOK( )
	{
    if ( !empty($_POST['login']) &&  // && ist das logische UND (oder: AND)
			   !empty($_POST['passwd'])   )
		{
			return true;
		}
		else
		{
      return false;
		}
	}
/* **********************************************************
	function Check_LoggedIn( );

  Überprüft, ob ein User bereits erfolgreich angemeldet ist.
	Ist keine Anmeldung erfolgt, so wird nach index.php umgelenkt
	mit der Fehlernummer 12.

	Parameter: keine 
	           ABER greift auf $_SESSION['login']['uid'] zu
	Rückgabewerte: keine
*********************************************************** */
function Check_LoggedIn()
{
  // ist der User angemeldet? Wenn ja -> dann existiert in der
	// SESSION die uid
	if ( !isset( $_SESSION['login']['uid'] ) )
	{
    // Fehler merken
		$_SESSION['err']['errno']=12;

		// SESSION-ID aufheben
		$ziel="./index.php?".SID;

		// umlenken
		header("Location: ".$ziel);
		/* alternativ:
		header("Location: ./index.php?".SID);
		*/
	}
}	
/* **********************************************************
	function Aktiv( );

  Überprüft, ob im $_POST ein Feld mit dem Namen ['Sperren']
	oder ['Aktivieren'] vorhanden ist und sperrt bzw. entsperrt diesen MenüPunkt 

	Parameter: $_POST['Sperren'], $_POST['Aktivieren']
	           
	Rückgabewerte: keine
*********************************************************** */
function Aktiv()
{
	if(isset( $_SESSION['login']['uid']))
	{
		if(isset( $_POST['Aktivieren']))
		{
			$ID = $_POST['Aktivieren'];	
			AktiviereMenu($ID);
			header("Location: ./verwaltung.php?".SID);
		}
		elseif(isset( $_POST['Sperren']))
		{
			$ID = $_POST['Sperren'];	
			SperreMenu($ID);
	
			header("Location: ./verwaltung.php?".SID);
		}
	}
	
}
?>