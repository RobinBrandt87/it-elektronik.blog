<?php
  //error_reporting(E_ALL);
  // $mydebug = true; besser als Konstante => global
	define( "MYDEBUG", True);

    ini_set( "session.use_cookies" , 0);
	ini_set( "session.use_only_cookies" , 0); // Für unsere Mac User only 4 you 
	session_name("RTB");
	session_start();

  include_once "./src/php_funcs.php";
  include_once "./src/db_funcs.php";
  include_once "./src/html_funcs.php";

  $Menu = Menu();
  $footer = footer();
  
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
          "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>

<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <title>IT-Elektronik Blog</title>
    <link rel="stylesheet" type="text/css" href="TechnikBlog.css" />
</head>

<body class="InhaltsSeite">
<?php echo $Menu; ?>

    <div id="Inhalt">
		
		<div class="Bild">
		<img width="140" height="240" src="Bilder/Passfoto.jpg" alt="Robin Brandt Autor dieser Webseite" />
    	</div>
		<div class="Impresum">
		<h1>Impressum</h1> 
		<h2>Angaben gem&auml;&szlig; &sect; 5 TMG:</h2> 
		<p>Robin Brandt<br /> Brodowiner Ring 24<br /> 12679 Berlin </p> 
		<h2>Kontakt:</h2> 
			
		<table>
			<tr><td>Telefon:</td><td>+49 (0) 175 8482934</td></tr> 	
			<tr><td>E-Mail:</td> <td>Robin@IT-Elektronik.Blog</td></tr>
		</table><br /><br /><br /><br /> 
		
		<h2>Verantwortlich f&uuml;r den Inhalt nach &sect; 55 Abs. 2 RStV:</h2>
		 <p>Robin Brandt<br /> Brodowiner Ring 24<br /> 12679 Berlin</p> 
		 <h2>Haftung f&uuml;r Inhalte</h2> 
		 <p>Als Diensteanbieter sind wir gem&auml;&szlig; &sect; 7 Abs.1 TMG f&uuml;r eigene Inhalte 
			auf diesen Seiten nach den allgemeinen Gesetzen verantwortlich. Nach &sect;&sect; 8 bis 10 TMG
			sind wir als Diensteanbieter jedoch nicht verpflichtet, &uuml;bermittelte oder gespeicherte 
			fremde Informationen zu &uuml;berwachen oder nach Umst&auml;nden zu forschen, die auf eine 
			rechtswidrige T&auml;tigkeit hinweisen.</p> 
		<p>Verpflichtungen zur Entfernung oder Sperrung der Nutzung von Informationen nach den 
			allgemeinen Gesetzen bleiben hiervon unber&uuml;hrt. Eine diesbez&uuml;gliche Haftung ist 
			jedoch erst ab dem Zeitpunkt der Kenntnis einer konkreten Rechtsverletzung m&ouml;glich. 
			Bei Bekanntwerden von entsprechenden Rechtsverletzungen werden wir diese Inhalte umgehend 
			entfernen.</p> 
			<h2>Haftung f&uuml;r Links</h2> 
			<p>Unser Angebot enth&auml;lt Links zu externen Webseiten Dritter, auf deren Inhalte wir 
			keinen Einfluss haben. Deshalb k&ouml;nnen wir f&uuml;r diese fremden Inhalte auch keine 
			Gew&auml;hr &uuml;bernehmen. F&uuml;r die Inhalte der verlinkten Seiten ist stets der 
			jeweilige Anbieter oder Betreiber der Seiten verantwortlich. Die verlinkten Seiten wurden 
			zum Zeitpunkt der Verlinkung auf m&ouml;gliche Rechtsverst&ouml;&szlig;e &uuml;berpr&uuml;ft. 
			Rechtswidrige Inhalte waren zum Zeitpunkt der Verlinkung nicht erkennbar.</p> 
			<p>Eine permanente inhaltliche Kontrolle der verlinkten Seiten ist jedoch ohne konkrete 
			Anhaltspunkte einer Rechtsverletzung nicht zumutbar. Bei Bekanntwerden von Rechtsverletzungen 
			werden wir derartige Links umgehend entfernen.</p> 
			<h2>Urheberrecht</h2> 
			<p>Die durch die Seitenbetreiber erstellten Inhalte und Werke auf diesen Seiten unterliegen 
			dem deutschen Urheberrecht. Die Vervielf&auml;ltigung, Bearbeitung, Verbreitung und jede Art 
			der Verwertung au&szlig;erhalb der Grenzen des Urheberrechtes bed&uuml;rfen der schriftlichen 
			Zustimmung des jeweiligen Autors bzw. Erstellers. Downloads und Kopien dieser Seite sind nur 
			f&uuml;r den privaten, nicht kommerziellen Gebrauch gestattet.</p> 
			<p>Soweit die Inhalte auf dieser Seite nicht vom Betreiber erstellt wurden, werden die 
			Urheberrechte Dritter beachtet. Insbesondere werden Inhalte Dritter als solche gekennzeichnet. 
			Sollten Sie trotzdem auf eine Urheberrechtsverletzung aufmerksam werden, bitten wir um einen 
			entsprechenden Hinweis. Bei Bekanntwerden von Rechtsverletzungen werden wir derartige Inhalte 
			umgehend entfernen.</p>
			<p>Quelle: <a href="https://www.e-recht24.de">e-recht24.de</a></p>

			<h1>Datenschutzerkl&auml;rung</h1> 
			<h2>Datenschutz</h2> 
			<p>Die Betreiber dieser Seiten nehmen den Schutz Ihrer pers&ouml;nlichen Daten sehr ernst. 
			Wir behandeln Ihre personenbezogenen Daten vertraulich und entsprechend der gesetzlichen 
			Datenschutzvorschriften sowie dieser Datenschutzerkl&auml;rung.</p> 
			<p>Die Nutzung unserer Webseite ist in der Regel ohne Angabe personenbezogener Daten 
			m&ouml;glich. Soweit auf unseren Seiten personenbezogene Daten (beispielsweise Name, 
			Anschrift oder E-Mail-Adressen) erhoben werden, erfolgt dies, soweit m&ouml;glich, stets 
			auf freiwilliger Basis. Diese Daten werden ohne Ihre ausdr&uuml;ckliche Zustimmung nicht 
			an Dritte weitergegeben.</p> 
			<p>Wir weisen darauf hin, dass die Daten&uuml;bertragung im Internet (z.B. bei der Kommunikation 
			per E-Mail) Sicherheitsl&uuml;cken aufweisen kann. Ein l&uuml;ckenloser Schutz der Daten vor 
			dem Zugriff durch Dritte ist nicht m&ouml;glich.</p>
			<p>&nbsp;</p> 
			<h2> Cookies</h2> 
			<p>Die Internetseiten verwenden teilweise so genannte Cookies. Cookies richten auf Ihrem Rechner 
			keinen Schaden an und enthalten keine Viren. Cookies dienen dazu, unser Angebot nutzerfreundlicher,
			 effektiver und sicherer zu machen. Cookies sind kleine Textdateien, die auf Ihrem Rechner abgelegt 
			 werden und die Ihr Browser speichert.</p> 
			<p>Die meisten der von uns verwendeten Cookies sind so genannte „Session-Cookies“. Sie werden nach 
			Ende Ihres Besuchs automatisch gel&ouml;scht. Andere Cookies bleiben auf Ihrem Endger&auml;t 
			gespeichert, bis Sie diese l&ouml;schen. Diese Cookies erm&ouml;glichen es uns, Ihren Browser beim 
			n&auml;chsten Besuch wiederzuerkennen.</p> <p>Sie k&ouml;nnen Ihren Browser so einstellen, dass 
			Sie &uuml;ber das Setzen von Cookies informiert werden und Cookies nur im Einzelfall erlauben, die 
			Annahme von Cookies f&uuml;r bestimmte F&auml;lle oder generell ausschlie&szlig;en sowie das 
			automatische L&ouml;schen der Cookies beim Schlie&szlig;en des Browser aktivieren. Bei der 
			Deaktivierung von Cookies kann die Funktionalit&auml;t dieser Website eingeschr&auml;nkt sein.</p>
			<p>&nbsp;</p> 
			<h2>Server-LogFiles</h2> 
			<p>Der Provider der Seiten erhebt und speichert automatisch Informationen in so genannten Server-Log 
			Files, die Ihr Browser automatisch an uns &uuml;bermittelt. Dies sind:</p> 
			 
				<p>- Browsertyp und Browserversion</p> 
				<p>- verwendetes Betriebssystem</p> 
				<p>- Referrer URL</p> 
				<p>- Hostname des zugreifenden Rechners</p> 
				<p>- Uhrzeit der Serveranfrage</p> 
			 
			<p>Diese Daten sind nicht bestimmten Personen zuordenbar. Eine Zusammenf&uuml;hrung dieser Daten 
			mit anderen Datenquellen wird nicht vorgenommen. Wir behalten uns vor, diese Daten 
			nachtr&auml;glich zu pr&uuml;fen, wenn uns konkrete Anhaltspunkte f&uuml;r eine rechtswidrige 
			Nutzung bekannt werden.</p> 
			<p>&nbsp;</p> 
			<h2>Facebook-Plugins (Like-Button)</h2> 
			<p>Auf unseren Seiten sind Plugins des sozialen Netzwerks Facebook, Anbieter Facebook Inc., 
			1 Hacker Way, Menlo Park, California 94025, USA, integriert. Die Facebook-Plugins erkennen Sie 
			an dem Facebook-Logo oder dem "Like-Button" ("Gef&auml;llt mir") auf unserer Seite. Eine &Uuml;bersicht
			&uuml;ber die Facebook-Plugins finden Sie hier: 
			<a href="http://developers.facebook.com/docs/plugins/"> http://developers.facebook.com/docs/plugins/</a>.</p>
			<p>Wenn Sie unsere Seiten besuchen, wird &uuml;ber das Plugin eine direkte Verbindung zwischen 
			Ihrem Browser und dem Facebook-Server hergestellt. Facebook erh&auml;lt dadurch die Information, 
			dass Sie mit Ihrer IP-Adresse unsere Seite besucht haben. Wenn Sie den Facebook "Like-Button" 
			anklicken w&auml;hrend Sie in Ihrem FacebookAccount eingeloggt sind, k&ouml;nnen Sie die Inhalte 
			unserer Seiten auf Ihrem Facebook-Profil verlinken. Dadurch kann Facebook den Besuch unserer 
			Seiten Ihrem Benutzerkonto zuordnen. Wir weisen darauf hin, dass wir als Anbieter der Seiten 
			keine Kenntnis vom Inhalt der &uuml;bermittelten Daten sowie deren Nutzung durch Facebook erhalten.
			Weitere Informationen hierzu finden Sie in der Datenschutzerkl&auml;rung von Facebook unter 
			<a href="http://de-de.facebook.com/policy.php">http://dede.facebook.com/policy.php</a>.</p> 
			<p>Wenn Sie nicht w&uuml;nschen, dass Facebook den Besuch unserer Seiten Ihrem Facebook-Nutzerkonto 
			zuordnen kann, loggen Sie sich bitte aus Ihrem FacebookBenutzerkonto aus.</p>
			<p>&nbsp;</p> 
			<h2>Twitter</h2> 
			<p>Auf unseren Seiten sind Funktionen des Dienstes Twitter eingebunden. Diese Funktionen werden 
			angeboten durch die Twitter Inc., 1355 Market Street, Suite 900, San Francisco, CA 94103, USA. 
			Durch das Benutzen von Twitter und der Funktion "ReTweet" werden die von Ihnen besuchten 
			Webseiten mit Ihrem Twitter-Account verkn&uuml;pft und anderen Nutzern bekannt gegeben. Dabei 
			werden auch Daten an Twitter &uuml;bertragen. Wir weisen darauf hin, dass wir als Anbieter der 
			Seiten keine Kenntnis vom Inhalt der &uuml;bermittelten Daten sowie deren Nutzung durch Twitter 
			erhalten. Weitere Informationen hierzu finden Sie in der Datenschutzerkl&auml;rung von Twitter unter 
			<a href="http://twitter.com/privacy"> http://twitter.com/privacy</a>.</p> 
			<p>Ihre Datenschutzeinstellungen bei Twitter k&ouml;nnen Sie in den Konto-Einstellungen unter: 
			<a href="http://twitter.com/account/settings"> http://twitter.com/account/settings</a> &auml;ndern.</p>
			<p>&nbsp;</p> <h2>XING</h2> <p>Unsere Webseite nutzt Funktionen des Netzwerks XING. Anbieter ist 
			die XING AG, Dammtorstra&szlig;e 29-32, 20354 Hamburg, Deutschland. Bei jedem Abruf einer unserer 
			Seiten, die Funktionen von XING enth&auml;lt, wird eine Verbindung zu Servern von XING hergestellt.
			 Eine Speicherung von personenbezogenen Daten erfolgt dabei nach unserer Kenntnis nicht. 
			 Insbesondere werden keine IPAdressen gespeichert oder das Nutzungsverhalten ausgewertet.</p> 
			<p>Weitere Information zum Datenschutz und dem XING Share-Button finden Sie in der Datenschutzerkl&auml;rung von XING unter: <a href="https://www.xing.com/app/share?op=data_protection"> https://www.xing.com/app/share?op=data_protection</a></p><p>&nbsp;</p> <h2>YouTube</h2> <p> Unsere Webseite nutzt Plugins der von Google betriebenen Seite YouTube. Betreiber der Seiten ist die YouTube, LLC, 901 Cherry Ave., San Bruno, CA 94066, USA. Wenn Sie eine unserer mit einem YouTubePlugin ausgestatteten Seiten besuchen, wird eine Verbindung zu den Servern von YouTube hergestellt. Dabei wird dem Youtube-Server mitgeteilt, welche unserer Seiten Sie besucht haben.</p> <p>Wenn Sie in Ihrem YouTube-Account eingeloggt sind erm&ouml;glichen Sie YouTube, Ihr Surfverhalten direkt Ihrem pers&ouml;nlichen Profil zuzuordnen. Dies k&ouml;nnen Sie verhindern, indem Sie sich aus Ihrem YouTube-Account ausloggen.</p> <p>Weitere Informationen zum Umgang von Nutzerdaten finden Sie in der Datenschutzerkl&auml;rung von YouTube unter: <a href="https://www.google.de/intl/de/policies/privacy">https://www.google.de/intl/de/policies/privacy</a></p> <p>&nbsp;</p> <h2>SSL-Verschl&uuml;sselung</h2> <p>Diese Seite nutzt aus Gr&uuml;nden der Sicherheit und zum Schutz der &Uuml;bertragung vertraulicher Inhalte, wie zum Beispiel der Anfragen, die Sie an uns als Seitenbetreiber senden, eine SSL-Verschl&uuml;sselung. Eine verschl&uuml;sselte Verbindung erkennen Sie daran, dass die Adresszeile des Browsers von &quot;http://&quot; auf &quot;https://&quot; wechselt und an dem Schloss-Symbol in Ihrer Browserzeile.</p> <p>Wenn die SSL Verschl&uuml;sselung aktiviert ist, k&ouml;nnen die Daten, die Sie an uns &uuml;bermitteln, nicht von Dritten mitgelesen werden.</p><p>&nbsp;</p> <h2>Widerspruch Werbe-Mails</h2> <p>Der Nutzung von im Rahmen der Impressumspflicht ver&ouml;ffentlichten Kontaktdaten zur &Uuml;bersendung von nicht ausdr&uuml;cklich angeforderter Werbung und Informationsmaterialien wird hiermit widersprochen. Die Betreiber der Seiten behalten sich ausdr&uuml;cklich rechtliche Schritte im Falle der unverlangten Zusendung von Werbeinformationen, etwa durch Spam-E-Mails, vor.</p><p>&nbsp;</p> <p>Quelle: <a href="https://www.e-recht24.de">eRecht24</a></p>
			
		</div>
	</div>	
    <?php echo $footer; ?>
</body>

</html>