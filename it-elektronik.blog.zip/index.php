<?php
  error_reporting(E_ALL);
  // $mydebug = true; besser als Konstante => global
	define( "MYDEBUG", True);

    ini_set( "session.use_cookies" , 0);
	ini_set( "session.use_only_cookies" , 0); // Für unsere Mac User only 4 you 
	session_name("RTB");
	//session_name("RTBB");
	session_start();
if ($_SESSION['SSL']['SSL'] == "") 
  {
      $_SESSION['SSL']['SSL'] = "True";
      //header('Location: http://localhost/RobinTechnikblog/index.php?'.SID);
      //header('Location: https://h2723355.stratoserver.net/RobinTechnikblogBeta/index.php?'.SID);
	  header('Location: https://www.it-elektronik.blog/index.php?'.SID);
  }
  include_once "./src/php_funcs.php";
  include_once "./src/db_funcs.php";
  include_once "./src/html_funcs.php";
  $info = "Bla";
  //$info = $_SERVER['REQUEST_URI'];
  $Menu = Menu();
  $SideMenu ="";
  $Inhalt ="";
    If(isset($_GET['ID']))
  {
  $ID = $_GET['ID'];
  if(isset($_GET['Sub']))
  {
    
    $SID = $_GET['Sub'];
    $SideMenu = SideMenu($ID,$SID);
  }
  else
  {
    $SideMenu = SideMenu($ID);
    
  }
  //DebugArr($_GET);
  //echo $ID;
  //echo $SID; 
  }
  if(isset($_GET['AID']))
  {
    $AID = $_GET['AID'];
  }
  else
  {
      $AID =1;
  }
  $Inhalt = Inhalt($AID);
  $footer = footer();
  //DebugArr($Inhalt); 


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
          "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>

<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <title>IT-Elektronik Blog</title>
    <link rel="stylesheet" type="text/css" href="TechnikBlog.css" />
</head>

<body class="StartSeite">
<?php echo $Menu; ?>
<?php echo $SideMenu; ?>
<?php echo $Inhalt; ?>  


<?php echo $footer; ?>
</body>

</html>